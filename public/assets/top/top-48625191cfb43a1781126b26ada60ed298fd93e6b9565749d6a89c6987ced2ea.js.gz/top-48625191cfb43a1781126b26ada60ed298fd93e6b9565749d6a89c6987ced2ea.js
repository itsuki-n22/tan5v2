//// キャッチコピーの表示 
jQuery(function(){
  $('#top-img p').hide().fadeIn(2000);
  $('#top-img h2').hide();
})

//// ロゴの表示
setTimeout(function(){ 
  $('#top-img h2').fadeIn(2000);
}, 2000); 
